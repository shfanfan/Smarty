
void jumpToEnd();
void clearBuffer(char* buffer, int len);
int parseInt(char*& buffer, int len);
int strncmp(char* str1, char* str2, int n);
void SerialPrintFormatted(int value, int digits, int sign);
//int strlen(const char* s);

